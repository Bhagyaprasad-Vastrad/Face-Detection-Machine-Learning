import cv2 #pip install opencv-python
#load the cascade
face_cascade = cv2.CascadeClassifier('face_detector.xml')
#read the input image
img = cv2.imread('test2.jpg')
#detect faces
faces = face_cascade.detectMultiScale(img,1.1,4)
#draw rectangle around the faces
for(x,y,w,h) in faces:
     cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),5)
#export the result
cv2.imwrite("face_detector.png",img)
print("Succussfully saved")

from PIL import Image
#python imaging library (abbreviated as PIL)(in newer versions
#is a free and open source additional library for a python progamming
#adds support for opening ,manipulation ,and saving many different
import pytesseract
#python-tessaract is an optical character recognition(ocr) tool for
import cv2
pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files (x86)\\Tesseract-OCR\\tesseract.exe'
img = "face.jpg"
t1=pytesseract.image_to_string(Image.open(img))
#print(pytesseract.image_to_string(Image.open(img)))
print(t1)
file1=open('recognized.txt','w')
file1.writelines(t1)
file1.close()
print("file created succussfully!")
